README
======

This ```week4``` folder contains the following materials:

+ Lecture notes:
  - ```slideshow_0.ipynb``` - 
  - ```images/``` - 
  - ```data``` - 
+ Labs:
  - **to be updated soon**
+ Description of the problem set:
  - **to be updated soon**
